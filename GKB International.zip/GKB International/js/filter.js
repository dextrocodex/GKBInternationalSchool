// Table Filter

function performReset() {
	document.getElementById("inputRegId").value = "";
	document.getElementById("inputClass").value = "";
	document.getElementById("inputSection").value = "";
}

function performReset1() {
	document.getElementById("inputRegId-1").value = "";
	document.getElementById("inputClass-1").value = "";
	document.getElementById("inputSection-1").value = "";
}

function performReset3() {
	document.getElementById('inputSession').value="";
	document.getElementById("inputRegId-3").value = "";
	document.getElementById("inputName").value = "";
	document.getElementById("inputPhone").value = "";
}

function validateRegistration(){
	document.getElementById('complete-registration').style.display='block';
}

function fillAddress(){
	if (document.getElementById('filladdress').checked == true)
	{
		var addr1 = document.getElementById("addr1").value;
		var addr2 = document.getElementById("addr2").value;
		var addrCity = document.getElementById("addrCity").value;
		var addrState = document.getElementById("addrState").value;
		var addrPin = document.getElementById("addrPin").value;
		var addrCountry = document.getElementById("addrCountry").value;
		
		var copyaddr1 = addr1;
		var copyaddr2 = addr2;
		var copyaddrC = addrCity;
		var copyState = addrState;
		var copyPin = addrPin;
		var copyCountry = addrCountry;
		
		
		document.getElementById("peraddr1").value = copyaddr1;
		document.getElementById("peraddr2").value = copyaddr2;
		document.getElementById("peraddr3").value = copyaddrC;
		document.getElementById("peraddr4").value = copyState;
		document.getElementById("peraddr5").value = copyPin;
		document.getElementById("peraddr6").value = copyCountry;

	}
	else if (document.getElementById('filladdress').checked  == false)
	{
		document.getElementById("peraddr1").value = '';
		document.getElementById("peraddr2").value = '';
		document.getElementById("peraddr3").value = '';
		document.getElementById("peraddr4").value = '';
		document.getElementById("peraddr5").value = '';
		document.getElementById("peraddr6").value = '';
	}

	if (document.getElementById('filladdress').checked == true && ((document.getElementById("peraddr1").value == '') || (document.getElementById("peraddr3").value == '') || (document.getElementById("peraddr4").value == ''))){
		document.getElementById('filladdress').checked = false;
		alert("Please first fill the current Address form completely.");
		document.getElementById("peraddr1").value = '';
		document.getElementById("peraddr2").value = '';
		document.getElementById("peraddr3").value = '';
		document.getElementById("peraddr4").value = '';
		document.getElementById("peraddr5").value = '';
		document.getElementById("peraddr6").value = '';
		document.getElementById("addr1").value='';
		document.getElementById("addr2").value='';
		document.getElementById("addrCity").value='';
		document.getElementById("addrState").value='';
		document.getElementById("addrPin").value='';
		document.getElementById("addrCountry").value='';

	}
}