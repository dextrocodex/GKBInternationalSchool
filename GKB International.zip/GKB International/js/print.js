function printData()
{
   var divToPrint=document.getElementById("feeForm");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}

$('#printButton').on('click',function(){
printData();
})

